
import React, { useState } from 'react';

export default function ForexLandingPage() {
  const [email, setEmail] = useState('');

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#eef2ff', display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '20px' }}>
      <div style={{ maxWidth: '600px', width: '100%', backgroundColor: 'white', borderRadius: '16px', padding: '24px', boxShadow: '0 10px 20px rgba(0,0,0,0.1)' }}>
        <h1 style={{ fontSize: '28px', fontWeight: 'bold', color: '#1e3a8a' }}>Start Your Forex Trading Journey</h1>
        <p style={{ color: '#374151', marginTop: '10px' }}>
          Discover how to make money online by trading global currencies. Download our <strong>free Forex Quickstart Guide</strong> and learn:
        </p>
        <ul style={{ color: '#374151', fontSize: '14px', marginTop: '12px' }}>
          <li>✔️ How forex trading works</li>
          <li>✔️ Avoid common beginner mistakes</li>
          <li>✔️ Why you must choose a trusted broker</li>
          <li>✔️ How to start with just $10</li>
        </ul>
        <div style={{ marginTop: '20px' }}>
          <label>Email to get the guide:</label><br />
          <input type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} style={{ width: '100%', padding: '10px', borderRadius: '8px', border: '1px solid #ccc', marginTop: '8px' }} />
          <button style={{ marginTop: '12px', width: '100%', padding: '12px', backgroundColor: '#1d4ed8', color: 'white', border: 'none', borderRadius: '8px', fontSize: '16px' }}>📥 Download Guide</button>
        </div>
        <div style={{ textAlign: 'center', marginTop: '20px', fontSize: '14px', color: '#6b7280' }}>
          Or jump straight in 👇<br />
          <a href="YOUR_CPA_LINK_HERE" style={{ color: '#2563eb', fontWeight: 'bold' }} target="_blank" rel="noreferrer">Register with Exness and Start Trading</a>
        </div>
      </div>
    </div>
  );
}
